# ChronoQuest: The Agentic Realm — Implementation Plan

## Overview

**ChronoQuest** is an AI-powered mobile RPG dungeon crawler where a Google Antigravity-orchestrated AI Dungeon Master (DM) drives all gameplay decisions. Every dungeon run is unique: the DM generates encounters, adapts difficulty in real-time, creates personalized narratives, and acts as a "referee" ensuring fair play.

**Tech Stack**: React (Vite), Vanilla CSS, Google Gemini API (simulated Antigravity orchestration)

---

## Game Concept: "The Agentic Realm"

A rogue-like RPG dungeon crawler where:
- The **AI Dungeon Master** generates infinite, balanced dungeon floors
- **Smart Enemies** learn from your combat patterns and counter-adapt
- **Living Narrative** — dialogue and world events are AI-generated per session
- **Dynamic Difficulty** — DM tracks your win/loss ratio and adjusts enemy power
- **Reward Loop**: Explore → Fight → Level Up → Deeper Dungeon

---

## Architecture

### Agentic Workflow (Antigravity Simulation)

```
Player Action
    ↓
[Session State Manager] — tracks HP, level, tactics used
    ↓
[AI Dungeon Master Agent] — Gemini API
    ├── Generates enemy encounters based on player level + behavior
    ├── Creates adaptive narrative text
    ├── Decides loot rarity (balanced by fairness referee)
    └── Adjusts difficulty score dynamically
    ↓
[Combat Referee Agent] — validates move legality + fair rewards
    ↓
[Feedback Layer] — UI updates, animations, XP/loot display
```

### Core Screens

1. **Start Screen** — Hero selection, lore intro
2. **Dungeon Map** — Procedural floor layout (rooms)
3. **Combat Screen** — Turn-based battle with AI-generated enemies
4. **Narrative Screen** — AI DM story text, NPC dialogue
5. **Inventory/Stats** — Real-time hero stats, equipment
6. **Victory/Death** — Reward summary, leaderboard

---

## Proposed File Structure

```
f:/Game/chronoquest/
├── src/
│   ├── App.jsx               — Main router/state
│   ├── main.jsx
│   ├── index.css             — Global design system
│   ├── components/
│   │   ├── StartScreen.jsx
│   │   ├── DungeonMap.jsx
│   │   ├── CombatScreen.jsx
│   │   ├── NarrativePanel.jsx
│   │   ├── HeroStats.jsx
│   │   ├── InventoryScreen.jsx
│   │   ├── RewardScreen.jsx
│   │   └── Leaderboard.jsx
│   ├── agents/
│   │   ├── DungeonMaster.js  — Core Antigravity agent orchestrator
│   │   ├── CombatReferee.js  — Validates actions, ensures fair play
│   │   └── NarrativeEngine.js — Generates story/dialogue
│   ├── game/
│   │   ├── gameState.js      — Central state management
│   │   ├── heroes.js         — Hero classes/abilities
│   │   ├── enemies.js        — Enemy archetypes
│   │   └── items.js          — Loot tables
│   └── utils/
│       ├── geminiClient.js   — Gemini API wrapper
│       └── animations.js     — CSS animation helpers
├── index.html
├── vite.config.js
└── package.json
```

## Verification Plan

- Build and run with `npm run dev`
- Test all 6 screens render correctly
- Test combat loop (attack, defend, special)
- Test AI DM generates content on each floor
- Verify difficulty scaling (win 3 fights → harder enemies)
- Test on mobile viewport (375px width)
