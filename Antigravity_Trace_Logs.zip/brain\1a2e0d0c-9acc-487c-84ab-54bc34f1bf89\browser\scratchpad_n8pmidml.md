# Task Checklist: ChronoQuest Game Trajectory

- [x] Resize browser to 390x844 (mobile size)
- [x] Navigate to start screen (reload page)
- [x] Take screenshot of Start Screen
- [x] Click "⚔️ Begin Your Quest"
- [x] Take screenshot after 1s (Character Selection)
- [x] Click Warrior card
- [x] Click "Begin as Warrior"
- [x] Wait 2s, click "Continue" on narrative panel
- [x] Take screenshot of Dungeon Map
- [x] Click "▶ Enter Room" on Room 1
- [x] Take screenshot of Combat Screen
- [ ] Click "Attack" button twice
- [ ] Take final screenshot
- [ ] Report back findings
