# ChronoQuest Build Tasks

## Setup
- [x] Scaffold Vite React project in f:/Game
- [x] npm install dependencies

## Game Logic
- [x] gameState.js — SCREENS, hero creation, XP/level/save systems
- [x] enemies.js — 9 archetypes, AI scaling, tactic-based AI actions
- [x] items.js — 15 items, rarity system, loot generation

## AI Agents (Antigravity)
- [x] DungeonMaster.js — orchestrator, behavior analysis, dynamic difficulty, floor generation
- [x] CombatReferee.js — damage validation, fair play, reward verification
- [x] NarrativeEngine.js — contextual story text, typewriter dialogue

## React Components
- [x] StartScreen.jsx — animated particles, spinning rings, CTA buttons
- [x] HeroSelect.jsx — 3-class selector with stat bars, pros/cons
- [x] DungeonMap.jsx — visual path with room nodes, boss warnings
- [x] CombatScreen.jsx — turn-based with floating damage, item picker, enemy AI
- [x] NarrativePanel.jsx — typewriter effect + AI decision log panel
- [x] HeroStats.jsx — vitals, stat grid, AI combat analysis tracker
- [x] InventoryScreen.jsx — item grid, detail panel, use/equip/drop
- [x] RewardScreen.jsx — animated XP/gold/loot reveal, level-up banner
- [x] Leaderboard.jsx — top-10 with medals, persistent localStorage
- [x] GameOver.jsx — final score, stats breakdown, restart

## App Shell
- [x] App.jsx — full game state machine, all screen routing
- [x] index.css — complete design system (tokens, animations, all components)
- [x] main.jsx — React entry point
- [x] index.html — mobile viewport, SEO meta tags

## Deliverables
- [x] README.md — game hook, architecture, hero/enemy tables, scoring
- [x] Dev server running at http://localhost:5173
- [x] Fix parse error (apostrophe in enemies.js lore string)
