# Task Plan: Test Mobile Game App

- [ ] Open http://localhost:5173 and take a screenshot of the start screen.
- [ ] Click "Begin Your Quest" and take a screenshot of the hero selection screen.
- [ ] Select "Warrior" hero and confirm.
- [ ] Wait for narrative screen and take a screenshot.
- [ ] Click "Continue" and take a screenshot of the dungeon map.
- [ ] Click "Enter Room" and take a screenshot of the combat screen.
- [ ] Click "Attack" a few times and take a screenshot of combat in action.
- [ ] Monitor console logs for errors.
- [ ] Provide a final report.