# High-Fidelity PDF to Word with ConvertAPI

## Goal
Implement ConvertAPI in the backend (`Server.js`) to achieve high-quality PDF to Word conversion. This replaces the local `soffice` solution and meets the user's requirements for OCR, layout preservation, and table reconstruction.

## User Review Required
> [!NOTE]
> **API Key**: Using the key provided: `wxGsVxuuIq0v56qeZXrO5WiguyVs2L92`.
> **Architecture**: I will implement this in the **Backend** (Node.js) rather than the Frontend. This keeps the API key secure (hidden from the browser client) and maintains the existing application structure.

## Proposed Changes

### Backend
#### [NEW DEPENDENCY] `convertapi`
- Install the `convertapi` Node.js library: `npm install convertapi`

#### [MODIFY] [Server.js](file:///e:/Apple/DocTransform%20App/Backend/Server.js)
- **Remove** `soffice` execution logic.
- **Import** `convertapi`.
- **Update** `/pdf-to-word` endpoint:
    1.  Save uploaded file to a temporary path (ConvertAPI handles files best).
    2.  Call `convertapi.convert('docx', { File: ... })`.
    3.  Download the converted file.
    4.  Send the file back to the frontend.
    5.  Clean up temporary files.

### Frontend
#### [MODIFY] [pdf2word.jsx](file:///e:/Apple/DocTransform%20App/Frontend/src/components/pdf2word.jsx)
- **No significant changes required**: The frontend already expects a generic binary response (Blob). The backend will fulfill this contract transparently. I will double-check the filename handling.

## Verification Plan

### Manual Verification
1.  **Install Dependency**: Run `npm install convertapi` in `Backend`.
2.  **Start Server**: `node Server.js`.
3.  **Test**: Upload a complex PDF (with tables/images) via the UI.
4.  **Validate**: Open the resulting DOCX to ensure it is editable and formatting is preserved.
